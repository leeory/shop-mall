由于seata1.0及以上的版本脚本都没在打包里面，需要自己到github上下载，找到对应的版本。具体的下载地址如下：
https://github.com/seata/seata/tree/1.4.0/script
https://github.com/seata/seata/tree/1.3.0/script